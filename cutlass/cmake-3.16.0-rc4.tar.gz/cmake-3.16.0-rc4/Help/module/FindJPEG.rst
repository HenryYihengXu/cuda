.. cmake-module:: ../../Modules/FindJPEG.cmake
