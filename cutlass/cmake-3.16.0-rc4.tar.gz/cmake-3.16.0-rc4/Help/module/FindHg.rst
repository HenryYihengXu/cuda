.. cmake-module:: ../../Modules/FindHg.cmake
